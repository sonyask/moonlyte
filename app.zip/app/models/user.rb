class User < ActiveRecord::Base
  has_one :moonlyter
  
end
