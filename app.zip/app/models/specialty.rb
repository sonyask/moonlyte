class Specialty < ActiveRecord::Base
end
