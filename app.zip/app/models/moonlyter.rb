class Moonlyter < ActiveRecord::Base
end
